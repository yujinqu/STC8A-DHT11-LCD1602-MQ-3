/*****************************************************************
ԭ�� �����
���Լӱ�������ר��qqȺ748182829
��˿Ⱥ375029515
ȫ���ļ����ؿ�ԴЭ��GPL 3.0
ת����ע�� ��bվ ����� ԭ��https://space.bilibili.com/397673409��
******************************************************************/
#include "LCD1602.h"
#include "delay.h"
void LCD_write_com(u8 com)//write order
{
	delay_ms(5);//5ms
	RS_CLR;
	RW_CLR;
	EN_SET;
	dataport=com;
	_nop_();
	EN_CLR;
}

void LCD_write_data(u8 data0)//write data
{
	delay_ms(5);
	RS_SET;
	RW_CLR;
	EN_SET;
	dataport=data0;
	_nop_();
	EN_CLR;//0
}

void LCD_clear()//clear screen
{
	LCD_write_com(0x01);
	delay_ms(5);
}

void LCD_write_string(u8 x,u8 y,u8 *s)//str function
{
	if(y==0)
	{
		LCD_write_com(0x80+x);
	}
	else
	{
		LCD_write_com(0xc0+x);
	}
	while(*s)
	{
		LCD_write_data(*s);
		s++;
	}
}

void LCD_write_char(u8 x,u8 y,u8 data0)
{
	if(y==0)
	{
		LCD_write_com(0x80+x);
	}
	else
	{
		LCD_write_com(0xc0+x);
	}
	LCD_write_data(data0);
}
u32 LCD1602_pow(u8 m,u8 n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}	
void LCD1602_ShowNum(u8 x,u8 y,long num,u8 len)
{         	
	u8 t,temp;
	u8 enshow=0;	
	if(y==0)
	{
		LCD_write_com(0x80+x);
	}
	else
	{
		LCD_write_com(0xc0+x);
	}					   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD1602_pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				
                LCD_write_char(x++,y,' ');
				continue;
			}else enshow=1; 
		 	 
		}
	 	
        LCD_write_char(x++,y,temp+'0'); 
	}
} 



void LCD_init()
{
	LCD_write_com(0x38);
	delay_ms(5);
	LCD_write_com(0x38);
	delay_ms(5);
	LCD_write_com(0x38);
	delay_ms(5);
	LCD_write_com(0x38);
	LCD_write_com(0x08);//display
	LCD_write_com(0x01);//clear screen
	LCD_write_com(0x06);//play light house move
	delay_ms(5);
	LCD_write_com(0x0c);//play out
}