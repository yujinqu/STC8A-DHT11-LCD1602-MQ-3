#ifndef __sys_H_
#define __sys_H_
#include <STC8.H>
#define  u8 unsigned char 
#define  u32 unsigned int
#endif